# variables.tf for ec2 auto scaling 
############################################## Common ####################################################################
variable "aws_region" {
	description	= "AWS Region where this resource will be created"
}

variable application_prefix {
    description     = "Prefix for roles and any other resource names which are dynamically changes per environment"
}

variable environment {
    description     = "A 3 letter word to represent environment used as suffix for resource names. eg., poc, d01m t01,p01 etc."
}

######################################## IAM Instance Profile & IAM Role ##############################################
variable iam_boundary_policy {
    description = "IAM Boundary Policy Name - Required to create role with delegate-admin as prefix"
}


variable ec2_lambda_iam {
	description	= "Does Ec2 IAM Role required Lambda Policy?"
	type		= bool
	default		= false
}

variable lambda_function_policy_resources {
	description	= "List of ARNs for Lambda Function Resources in Ec2 IAM Policy"
}

variable ec2_sqs_queue_iam {
	description	= "Does Ec2 IAM Role required SQS Queue Policy?"
	type		= bool
	default		= false
}

variable sqs_queue_policy_resources {
	description	= "List of ARNs for SQS Queue Resources in Ec2 IAM Policy"
}

variable ec2_sns_topic_iam {
	description	= "Does Ec2 IAM Role required SNS Topic Policy?"
	type		= bool
	default		= false
}

variable sns_topic_policy_resources {
	description	= "List of ARNs for SNS Topic Resources in Ec2 IAM Policy"
}

variable ec2_kinesis_stream_iam {
	description	= "Does Ec2 IAM Role required Kinesis Stream Policy?"
	type		= bool
	default		= false
}

variable kinesis_stream_policy_resources {
	description	= "List of ARNs for Kinesis Stream Resources in Ec2 IAM Policy"
}

variable ec2_kms_key_iam {
	description	= "Does Ec2 IAM Role required KMS Key Policy?"
	type		= bool
	default		= false
}

variable kms_key_policy_resources {
	description	= "List of ARNs for KMS Key Resources in Ec2 IAM Policy"
}

variable ec2_secrets_iam {
	description	= "Does Ec2 IAM Role required Secrets Policy?"
	type		= bool
	default		= false
}

variable secrets_policy_resources {
	description	= "List of ARNs for Secrets Resources in Ec2 IAM Policy"
}

variable ec2_dynamodb_iam {
	description	= "Does Ec2 IAM Role required Dynamo DB Policy?"
	type		= bool
	default		= false
}

variable dynamo_db_policy_resources {
	description	= "List of ARNs for Dynamo DB Resources in Ec2 IAM Policy"
}

variable ec2_s3bucket_iam {
	description	= "Does Ec2 IAM Role required S3 Bucket Policy?"
	type		= bool
	default		= false
}

variable s3bucket_policy_resources {
	description	= "List of ARNs for S3 Bucket Resources in Ec2 IAM Policy"
}

variable ec2_ecraccess_iam {
	description	= "Does Ec2 IAM Role required ECR access Policy?"
	type		= bool
	default		= false
}

variable ecraccess_policy_resources {
	description	= "List of ARNs for ECR Access Resources in Ec2 IAM Policy"
}

variable ec2_athena_iam {
	description	= "Does Ec2 IAM Role required Athena Policy?"
	type		= bool
	default		= false
}

variable athena_policy_resources {
	description	= "List of ARNs for Athena Resources in Ec2 IAM Policy"
}

variable ec2_glue_iam {
	description	= "Does Ec2 IAM Role required Glue Policy?"
	type		= bool
	default		= false
}

variable glue_policy_resources {
	description	= "List of ARNs for Glue Resources in Ec2 IAM Policy"
}
########################################## Launch Template ############################################################
variable ec2_ami_image_id {
	description	= "AMI for the ec2 auto scale"
}

variable "deletion_protection" {
	description	= "If true, enables EC2 Instance Termination Protection"
	type		= bool
}

variable ec2_instance_type {
    description	= "The type of instance to start. Updates to this field will trigger a stop/start of the EC2 instance."
}

variable ec2_instance_key_name {
	description	= "The key name of the Key Pair to use for the instance"
}

variable additional_sg {
    description = "List of addl. security gropus to be attached to the ec2 instances"
    type        = list(string)
}
############################################################### Template File Variables #######################################################

# variable "host_name" {
# 	description	= "Name of the Ec2 Instance"
# }

variable "ora_software_s3_bucket" {
	description	= "Name of the S3 bucket where Oracle Binaries are stored"
	default		= "efx-cloud-gfs-nonprod-orabinaries"
}

variable "host_user_ldap_group" {
	description	= "Name of the LDAP group for the users to own to login to the EC2 instance. e.g., al_gfs_cdh_app_dev_user"
}

variable "server_tz" {
	description 	= "Time Zone of the EC2 Instance. Should match the requirements of the Application"
}

variable "host_sudoer_ldap_group" {
	description	= "Name of the sudoers group for the users to sudo to other OS users like root etc. e.g., al_gfs_cdh_app_dev_sudouser"
}
variable old_app_sg_ldap_group {
	description			= " Name of the Server Group for the Source EC2 to allow login access for App users"
}

variable old_app_sudoer_ldap_group {
	description			= " Name of the Sudoer Group for the Source EC2 to allow sudo access for App users"
}

variable new_app_sg_ldap_group {
	description			= " Name of the Server Group for the Target EC2 to allow login access for App users"
}

variable new_app_sudoer_ldap_group {
	description			= " Name of the Sudoer Group for the Target EC2 to allow sudo access for App users"
}
variable "edsps_sudoer_ldap_group" {
        description     = "Name of the sudoers group for the users to sudo to other OS users like root etc. e.g., al_gfs_cdh_app_dev_sudouser"
}
variable eds_user {
	description			= " Name of the Server Group for the Source EC2 to allow login access for App users"
}

variable app_name {
	description			= " Name of the Sudoer Group for the Source EC2 to allow sudo access for App users"
}

variable account_id {
	description			= " Name of the Server Group for the Target EC2 to allow login access for App users"
}

variable app_vrs {
	description			= " Name of the Sudoer Group for the Target EC2 to allow sudo access for App users"
}

variable app_port {
	description			= " Name of the Sudoer Group for the Target EC2 to allow sudo access for App users"
}
########################################### Auto Scaling Group ########################################################
variable ec2_instance_count_min {
    description = "The minimum size of the auto scale group"
}

variable ec2_instance_count_max {
    description = "The maximum size of the auto scale group"
}

variable ec2_desired_capacity {
    description = "The number of Amazon EC2 instances that should be running in the group."
}

variable subnet_id_list {
    description = "A list of subnet IDs to launch resources in"
    type        = list(string)
}
########################################### ASG Policy & CW Alarms ############################################################
variable autoscaling_policies_enabled {
	description	= "Whether auto scaling policy is enabled"
	type		= bool
	default		= false
}

variable asg_adjustment_type {
	description	= "Specifies whether the adjustment is an absolute number or a percentage of the current capacity. Valid values are ChangeInCapacity, ExactCapacity, and PercentChangeInCapacity."
	default		= "ChangeInCapacity"
}

variable asg_policy_type {
	description	= "The policy type, either SimpleScaling, StepScaling or TargetTrackingScaling. If this value isn't provided, AWS will default to SimpleScaling."
	default		= "SimpleScaling"
}

variable asg_estimated_instance_warmup {
	description	= "The estimated time, in seconds, until a newly launched instance will contribute CloudWatch metrics."
	default		= "300"
}

variable metric_aggregation_type4 {
	description	= "The aggregation type for the policy's metrics. Valid values are Minimum, Maximum, and Average."
	default		= "Average"
}

variable scaling_up_adjustment {
	description	= "The number of members by which to scale, when the adjustment bounds are breached. A positive value scales up. A negative value scales down."
	default		= 1
}

variable metric_interval_lower_bound_up {
	description	= "The lower bound for the difference between the alarm threshold and the CloudWatch metric."
	default		= 2.0
}

variable metric_interval_upper_bound_up {
	description	= "The upper bound for the difference between the alarm threshold and the CloudWatch metric."
	default		= 3.0
}

variable scaling_down_adjustment {
	description	= "The number of members by which to scale, when the adjustment bounds are breached. A positive value scales up. A negative value scales down."
	default		= -1
}

variable metric_interval_lower_bound_down {
	description	= "The lower bound for the difference between the alarm threshold and the CloudWatch metric."
	default		= 1.0
}

variable metric_interval_upper_bound_down {
	description	= "The upper bound for the difference between the alarm threshold and the CloudWatch metric."
	default		= 2.0
}

# CW Alarms
# High CPU 
variable cpu_utilization_high_evaluation_periods {
	description	= "The number of periods over which data is compared to the specified threshold."
	default		= 2
}

variable cpu_utilization_high_period_seconds {
	description	= "The period in seconds over which the specified statistic is applied."
	type		= number
	default		= 300
}

variable cpu_utilization_high_statistic {
	description			= "The statistic to apply to the alarm's associated metric. Either of the following is supported: SampleCount, Average, Sum, Minimum, Maximum"
	default				= "Average"
}

variable cpu_utilization_high_threshold_percent {
	description			= "The value against which the specified statistic is compared."
	default				= 60
}
# Low CPU
variable cpu_utilization_low_evaluation_periods {
	description	= "The number of periods over which data is compared to the specified threshold."
	default		= 2
}

variable cpu_utilization_low_period_seconds {
	description	= "The period in seconds over which the specified statistic is applied."
	type		= number
	default		= 300
}

variable cpu_utilization_low_statistic {
	description			= "The statistic to apply to the alarm's associated metric. Either of the following is supported: SampleCount, Average, Sum, Minimum, Maximum"
	default				= "Average"
}

variable cpu_utilization_low_threshold_percent {
	description			= "The value against which the specified statistic is compared."
	default				= 50
}

# Memory CW Alarms
variable as_memory_policies_enabled {
	description	= "Whether to enable Auto Scale Memory Policies"
	type		= bool
	default		= false
}

# High Memory 
variable memory_utilization_high_evaluation_periods {
	description	= "The number of periods over which data is compared to the specified threshold."
	default		= 2
}

variable memory_utilization_high_period_seconds {
	description	= "The period in seconds over which the specified statistic is applied."
	type		= number
	default		= 300
}

variable memory_utilization_high_statistic {
	description			= "The statistic to apply to the alarm's associated metric. Either of the following is supported: SampleCount, Average, Sum, Minimum, Maximum"
	default				= "Average"
}

variable memory_utilization_high_threshold_percent {
	description			= "The value against which the specified statistic is compared."
	default				= 60
}
# Low Memory
variable memory_utilization_low_evaluation_periods {
	description	= "The number of periods over which data is compared to the specified threshold."
	default		= 2
}

variable memory_utilization_low_period_seconds {
	description	= "The period in seconds over which the specified statistic is applied."
	type		= number
	default		= 300
}

variable memory_utilization_low_statistic {
	description			= "The statistic to apply to the alarm's associated metric. Either of the following is supported: SampleCount, Average, Sum, Minimum, Maximum"
	default				= "Average"
}

variable memory_utilization_low_threshold_percent {
	description			= "The value against which the specified statistic is compared."
	default				= 50
}

######################################## Security Groups ###############################################################
variable vpc_id {
    description     = "VPC ID where the ec2 instances are going to be provisioned"
}

variable "ingress_block" {
        description     = "A list of map of ingress blocks to create security groups"
        type            = list(map(string))

}

variable "egress_block" {
        description     = "A list of map of egress blocks to create security groups"
        type            = list(map(string))

}

######################################################################################################################################
#                                                            TAGS
######################################################################################################################################
#################################################### Specific to Resource Tags ############################################

variable "name_tag" {
	description	= "Name of the resource"
}

variable "costcenter_tag" {
	description	= "Cost Center of Business Unit or Tribe"
}

variable "projectname_tag" {
	description	= "Project Name of the resource. e.g., <Application_Group>-<Application>-<Purpose>"
}

variable "application_group_tag" {
	description	= "Name of the application Group. e.g., MDM, C2O, EDH , EDS etc."
}

variable "application_tag" {
	description	= "Name of the application"
}

variable "component_type_tag" {
	description	= "Database or Application Component for an Application. e.g., For AIA DB - aiadb, For AIA Application - aiaapp"
}

variable "tier_tag" {
	description	= "Database or Application or Web Tier of the resource"
}

variable "iac_tag" {
	description	= "Infrastructure Code directory structure in Bitbucket"
}

variable "environment_tag" {
	description	= "Stack # of the environment where the resource is created, e.g., d03 in pedslabd03d01" 
}

variable "sdlc_env_tag" {
	description	= "SDLC Environment Name - Dev/Test/UAT/Stage/Prod"
}

##############################################################################################################################