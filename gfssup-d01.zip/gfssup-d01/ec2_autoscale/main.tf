
module "ec2_autoscale" {

    source                          = "../../../../../../../modules/compute/ec2/ec2_autoscale"
    
    aws_region                      = var.aws_region
    application_prefix              = var.application_prefix
    environment                     = var.environment

    # IAM Role
    iam_boundary_policy             = var.iam_boundary_policy
    ec2_lambda_iam                  = var.ec2_lambda_iam
    lambda_function_policy_resources    = var.lambda_function_policy_resources
    ec2_sqs_queue_iam               = var.ec2_sqs_queue_iam
    sqs_queue_policy_resources      = var.sqs_queue_policy_resources
    ec2_sns_topic_iam               = var.ec2_sns_topic_iam
    sns_topic_policy_resources      = var.sns_topic_policy_resources
    ec2_kinesis_stream_iam          = var.ec2_kinesis_stream_iam
    kinesis_stream_policy_resources = var.kinesis_stream_policy_resources
    ec2_kms_key_iam                 = var.ec2_kms_key_iam
    kms_key_policy_resources        = var.kms_key_policy_resources
    ec2_secrets_iam                 = var.ec2_secrets_iam
    secrets_policy_resources        = var.secrets_policy_resources
    ec2_dynamodb_iam                = var.ec2_dynamodb_iam
    dynamo_db_policy_resources      = var.dynamo_db_policy_resources
    ec2_s3bucket_iam                = var.ec2_s3bucket_iam
    s3bucket_policy_resources       = var.s3bucket_policy_resources
    ec2_ecraccess_iam                = var.ec2_ecraccess_iam
    ecraccess_policy_resources       = var.ecraccess_policy_resources
    ec2_athena_iam                   = var.ec2_athena_iam
    athena_policy_resources          = var.athena_policy_resources
    ec2_glue_iam                     = var.ec2_glue_iam
    glue_policy_resources            = var.glue_policy_resources

    # Launch Template
    ec2_ami_image_id                = var.ec2_ami_image_id
    deletion_protection             = var.deletion_protection
    ec2_instance_type               = var.ec2_instance_type
    ec2_instance_key_name           = var.ec2_instance_key_name
    additional_sg                   = var.additional_sg
    
    # Template File Variables
	# host_name		                = var.host_name
    ora_software_s3_bucket          = var.ora_software_s3_bucket
	server_tz		                = var.server_tz
	host_user_ldap_group	        = var.host_user_ldap_group
	host_sudoer_ldap_group	        = var.host_sudoer_ldap_group
    edsps_sudoer_ldap_group	        = var.edsps_sudoer_ldap_group
    old_app_sg_ldap_group		    = var.old_app_sg_ldap_group
    old_app_sudoer_ldap_group	    = var.old_app_sudoer_ldap_group
    new_app_sg_ldap_group		    = var.new_app_sg_ldap_group
    new_app_sudoer_ldap_group	    = var.new_app_sudoer_ldap_group

    eds_user                        = var.eds_user
    account_id                      = var.account_id
    app_name                        = var.app_name
    app_vrs                         = var.app_vrs
    app_port                        = var.app_port

    # Auto Scaling Group
    ec2_instance_count_min          = var.ec2_instance_count_min
    ec2_instance_count_max          = var.ec2_instance_count_max
    ec2_desired_capacity            = var.ec2_desired_capacity
    subnet_id_list                  = var.subnet_id_list

    # ASG Policy & CW Alarms
    autoscaling_policies_enabled    = var.autoscaling_policies_enabled
    as_memory_policies_enabled      = var.as_memory_policies_enabled
    asg_policy_type                 = var.asg_policy_type   

    scaling_up_adjustment           = var.scaling_up_adjustment
    metric_interval_lower_bound_up  = var.metric_interval_lower_bound_up
    metric_interval_upper_bound_up  = var.metric_interval_upper_bound_up

    scaling_down_adjustment         = var.scaling_down_adjustment
    metric_interval_lower_bound_down    = var.metric_interval_lower_bound_down
    metric_interval_upper_bound_down    = var.metric_interval_upper_bound_down

    # CPU Autoscale CW Alarms
    cpu_utilization_high_evaluation_periods = var.cpu_utilization_high_evaluation_periods
    cpu_utilization_high_threshold_percent  = var.cpu_utilization_high_threshold_percent
    cpu_utilization_low_evaluation_periods  = var.cpu_utilization_low_evaluation_periods
    cpu_utilization_low_threshold_percent   = var.cpu_utilization_low_threshold_percent

    # Memory Autoscale CW Alarms
    memory_utilization_high_evaluation_periods = var.memory_utilization_high_evaluation_periods
    memory_utilization_high_threshold_percent  = var.memory_utilization_high_threshold_percent
    memory_utilization_low_evaluation_periods  = var.memory_utilization_low_evaluation_periods
    memory_utilization_low_threshold_percent   = var.memory_utilization_low_threshold_percent

    # Security Groups
    vpc_id                          = var.vpc_id
    ingress_block                   = var.ingress_block
    egress_block                    = var.egress_block
    
    # ALB    

    # Tags (ALL Lowercase!)
    # Specific to EC2 Resource
    name_tag                = var.name_tag
    root_volume_name_tag	= "${var.name_tag}_root_volume"
    costcenter_tag          = var.costcenter_tag
    projectname_tag         = var.projectname_tag
    application_group_tag   = var.application_group_tag
    application_tag         = var.application_tag
    component_type_tag      = var.component_type_tag
    iac_tag			        = var.iac_tag
    tier_tag                = var.tier_tag
    environment_tag         = var.environment_tag
    sdlc_env_tag            = var.sdlc_env_tag
    }