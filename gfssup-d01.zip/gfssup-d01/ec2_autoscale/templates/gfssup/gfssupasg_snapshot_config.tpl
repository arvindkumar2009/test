#!/bin/bash

##################################################################################################################
# DESCRIPTION	:	This is master script for GFSSUP Application Ec2 Autoscale Server Configuraiton
#       			This script will call all required scripts and ansible files to configure App Server
# Note: This is created from a pre-created golden image where all pre-req agents, pkgs are already installed
# The dev env LDAP groups are already configured for app and SRE teams in /etc/nslcd.conf and /etc/sudoers.d/*
##################################################################################################################


# Enable Login prompt for LDAP user
sed -i 's/^PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config


# Add /etc/hosts entry for the host IP
sed -i '/gfs.aws.efx/d' /etc/hosts
echo `ifconfig |grep broadcast|awk '{ print $2 }'` `hostname|sed 's/.gfs.aws.efx//'` `hostname` >> /etc/hosts


# Configure the Login and sudo group for login and sudo to root
sudo cp -p /etc/nslcd.conf /etc/nslcd.conf.orig
# Login Setup
sed -i "s/fintech_app_dev_global/"${edsps_sudoer_ldap_group}"/" /etc/nslcd.conf > /tmp/ldap.output
sed -i "s/"${old_app_sg_ldap_group}"/"${new_app_sg_ldap_group}"/" /etc/nslcd.conf >> /tmp/ldap.output
# Sudo Setup
sed -i "s/fintech_app_dev_global/"${edsps_sudoer_ldap_group}"/" /etc/sudoers.d/* 2> /tmp/sudo.output
sed -i "s/"${old_app_sudoer_ldap_group}"/"${new_app_sudoer_ldap_group}"/" /etc/sudoers.d/* 2>> /tmp/sudo.output


# Temporary CW agent config  - Change CW Log group name dynamically
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a stop
sed -i 's/GFSSUP-Application/GFSSUP-Application-${environment_tag}/' /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.d/file_config.json
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a start

# Restart services (Do not reboot as the asg requires to spin off new ec2s quickly)
systemctl restart sshd
service nslcd restart
