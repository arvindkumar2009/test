# # Outputs for EC2 Instance 
# output "ec2_instace_private_ip" {
#         description = "List of private IP addresses assigned to the instances"
#         value       = module.ec2_autoscale.ec2_instace_private_ip
# }
# output "ec2_instance_id" {
#         description = "The ID of the EC2 instance"
# 	value=module.ec2_autoscale.ec2_instance_id
# }


