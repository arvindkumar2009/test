#################################################################################################################################
# Terraform.tf for GFS SUP Ec2 Auto Scale
# Refer to variables.tf for description and default value of each attribute
#################################################################################################################################

# Provider
aws_region		                = "us-east-1"

# Prefix variables
application_prefix              = "gfssup"
environment                     = "d01"

# IAM Role
# For Prod account, use efx-developerpoweruser-boundary; Non Prod account, use efx-cloud-developerpoweruser-boundary-policy
iam_boundary_policy             = "efx-cloud-developerpoweruser-boundary-policy"
ec2_lambda_iam                  = "true"
lambda_function_policy_resources = ["arn:aws:lambda:us-east-1:504542583234:function:gfssup-kinesis-stream-processor-d01","arn:aws:lambda:us-east-1:504542583234:function:gfssup-kinesis-stream-processor-d01:*"]
ec2_sqs_queue_iam               = "true"
sqs_queue_policy_resources      = ["arn:aws:sqs:us-east-1:504542583234:gfssup-kinesis-stream-lambda-dlq-d01"]
ec2_sns_topic_iam               = "true"
sns_topic_policy_resources      = ["arn:aws:sns:us-east-1:504542583234:gfssup-alerts-d01"]
ec2_kinesis_stream_iam          = "true"
kinesis_stream_policy_resources = ["arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01"]
ec2_kms_key_iam                 = "true"
kms_key_policy_resources        = ["arn:aws:kms:us-east-1:504542583234:key/712bcd96-52fc-4557-b2e1-7cc734d13424"]
ec2_secrets_iam                 = "true"
secrets_policy_resources        = ["arn:aws:secretsmanager:us-east-1:504542583234:secret:gfssup/microservice/dev/d01/dynamodb*"]
ec2_dynamodb_iam                = "true"
dynamo_db_policy_resources      = ["arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-StreamTransactions-d01",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-StreamTransactions-d01/*",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-BatchTransactions-d01",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-BatchTransactions-d01/*",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-MetaDataTransactions-d01",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-MetaDataTransactions-d01/*",
                                    "arn:aws:dynamodb:us-east-1:504542583234:table/gfssup-StreamProcessor-d01"
                                ]
ec2_s3bucket_iam                = "true"
s3bucket_policy_resources       = ["arn:aws:s3:::efx-atlas-sup/*", "arn:aws:s3:::efx-atlas-sup","arn:aws:s3:::efx-atlas-d01/*", "arn:aws:s3:::efx-atlas-d01", "arn:aws:s3:::efx-gfssup-d01/*", "arn:aws:s3:::efx-gfssup-d01"]

ec2_ecraccess_iam                = "true"
ecraccess_policy_resources       = ["*"]

ec2_athena_iam                   = "true"
athena_policy_resources          = ["arn:aws:athena:us-east-1:504542583234:workgroup/primary"]

ec2_glue_iam                     = "true"
glue_policy_resources            = ["arn:aws:logs:*:*:/aws-glue/*"]

# Launch Template
# AMI Name:pgfssupd01a01_gfssup_ec2_as_gold_image_dev - "ami-09c28077bc2474aa9" - With all the software, CWagent  loaded 
ec2_ami_image_id                = "ami-09c28077bc2474aa9"

deletion_protection             = "false"
ec2_instance_type               = "t3.medium"
ec2_instance_key_name           = "eds_nonprod"
additional_sg                   = []

# userdata Template Variables - From Golden Image
ora_software_s3_bucket          = "efx-cloud-gfs-nonprod-orabinaries"
server_tz		                = "UTC"
# Give Server group for User access 
host_user_ldap_group	        = "sg_al_microservices_dev" 
host_sudoer_ldap_group	        = "fintech_app_dev_global"

# App LDAP Groups old and new (For snapshot configuration)
# Server Group(for Login) and Sudo LDAP groups for Application Users from Source Ec2
old_app_sg_ldap_group           = "sg_al_microservices_dev"
old_app_sudoer_ldap_group       = "al_microservices_dev_sudouser"
# Server Group(for Login) and Sudo LDAP groups for Application Users from Target Ec2
new_app_sg_ldap_group           = "sg_al_microservices_test"
new_app_sudoer_ldap_group       = "al_microservices_test_sudouser"
# Give EDS Platform Svc Blanket Sudo group for User & Sudo access 
edsps_sudoer_ldap_group	        = "fintech_app_test_global"

eds_user                        = "svc_eds_devops"
account_id                      = "504542583234"
app_name                        = "sup-gfs-dynamodb-stream-processor"
app_vrs                         = "latest"
app_port                        = "7075"

# Auto Scaling Group
ec2_instance_count_min          = 2
ec2_instance_count_max          = 4
ec2_desired_capacity            = 2

# ASG Policy & CW Alarms
autoscaling_policies_enabled    = "true"
as_memory_policies_enabled      = "true"
asg_policy_type                 = "StepScaling"

scaling_up_adjustment           = 1
metric_interval_lower_bound_up  = 2.0
metric_interval_upper_bound_up  = null

scaling_down_adjustment             = -1
metric_interval_lower_bound_down    = 1.0
metric_interval_upper_bound_down    = null

# CPU Autoscale CW Alarms
cpu_utilization_high_evaluation_periods = 2
cpu_utilization_high_threshold_percent  = 60
cpu_utilization_low_evaluation_periods  = 2
cpu_utilization_low_threshold_percent   = 50

# Memory Autoscale CW Alarms
memory_utilization_high_evaluation_periods = 2
memory_utilization_high_threshold_percent  = 60
memory_utilization_low_evaluation_periods  = 2
memory_utilization_low_threshold_percent   = 50

# Dev public subnets
#subnet_id_list                  = ["subnet-0d37b495fb8c48b4f1","subnet-06d713634d73f9a05"]
# Test private subnets
subnet_id_list                  = ["subnet-06c8b677540d68c47","subnet-00a3635d96c46b252"]

# Security Groups
# Dev VPC - "vpc-02ee7d0d498098fe2"; # Test VPC - "vpc-0396117afba4ad898"
vpc_id                          = "vpc-0396117afba4ad898"

# Ingress rules configurations. Please follow the requested structure at the moment you want to add new blocks
ingress_block    =[
                    {
                        from_port       =  2738 
                        to_port         =  2738 
                        protocol        = "tcp"
                        cidr_blocks     = "10.25.54.231/32"
                        description     = "ITAM UD Agent"
                    },
                    {
                        from_port       = 80  
                        to_port         = 80  
                        protocol        = "tcp"
                        cidr_blocks     = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
                        description     = "HTTP ports"
                    },
                    {
                        from_port       = 443  
                        to_port         = 443  
                        protocol        = "tcp"
                        cidr_blocks     = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
                        description     = "HTTPS ports"
                    },
                                        {
                        from_port       = 22  
                        to_port         = 22  
                        protocol        = "tcp"
                        cidr_blocks     = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
                        description     = "SSH ports"
                    },
                                        {
                        from_port       = 7075  
                        to_port         = 7076
                        protocol        = "tcp"
                        cidr_blocks     = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
                        description     = "Spring boot Application ports"
                    },
                  ]


# Egress rules configurations. Please follow the requested structure at the moment you want to add new blocks
egress_block    =[
                    {
                        from_port       = 0
                        to_port         = 0
                        protocol        = "-1"
                        cidr_blocks     = "0.0.0.0/0"
                        description = "Allow all Traffic"
                    },
                  ]

# Tags (ALL Lowercase!)
# Specific to Resource
name_tag		        = "gfssup-d01"
# Put costcenter in a map and list variable (child common module)
costcenter_tag		    = "20/7169"
projectname_tag		    = "gfs-sup"
application_group_tag	= "mis"
application_tag		    = "gfssup"
component_type_tag	    = "gfssupapp"
iac_tag			        = "eds_aws_iaac"
tier_tag		        = "app"
environment_tag		    = "d01"
sdlc_env_tag		    = "dev"
######################################################################################################################
