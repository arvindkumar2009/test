#terraform {
#  backend "s3" {
#    encrypt        = true
#    bucket         = "efx-cloud-gfs-nonprod-core-backend"
#    dynamodb_table = "LockingTable"
#    region         = "us-east-1"
#    key            = "eds/aws/nonprod-acc/us-east-1/dev-vpc/dev-env/gfssup/gfssup-d01/terraform-gfssup-d01.tfstate"
#  }
#}

## test 
terraform {
  backend "s3" {
    #encrypt        = true
    bucket         = "arv-2009"
    #dynamodb_table = "LockingTable"
    region         = "us-west-2"
    key            = "nagesh/terraform-gfssup-d01.tfstate"
  }
}

