# streams_variables.tf

################################################## Kinesis Data Stream Variables #####################################################

variable shard_count {
    description             = "The number of shards that the stream will use."
    default                 = 1
}

variable stream_retention_period_in_hrs {
    description             = "Length of time data records are accessible after they are added to the stream. The maximum value of a stream's retention period is 168 hours. Minimum value is 24. Default is 24."
    default                 = 24
}

variable stream_encryption_type {
    description             = "The encryption type to use. The only acceptable values are NONE or KMS. The default value is NONE."
    default                 = "NONE"
}

variable stream_encryption_kms_key_id {
    description             = "The GUID for the customer-managed KMS key to use for encryption. You can also use a Kinesis-owned master key by specifying the alias alias/aws/kinesis."
    default                 = ""
}
#############################################################################################################################