# variables.tf for Manual steps or Post-provisioing of GFS SUP architecture
############################################## Common ####################################################################
variable "aws_region" {
	description	= "AWS Region where this resource will be created"
}

variable application_prefix {
    description     = "Prefix for roles and any other resource names which are dynamically changes per environment"
}

variable environment {
    description     = "A 3 letter word to represent environment used as suffix for resource names. eg., poc, d01m t01,p01 etc."
}
# ================================================= Kinesis Stream Consumer Trigger for Lambda ==========================
variable kinesis_stream_consumer_arn {
    description          = "ARN of the Kinesis Stream Consumer Fan-out"
}

# Lambda Trigger
variable lambda_function_name_sqs {
    description         = "Name of the Lambda function"
}

variable batch_size {
    description         = "The largest number of records that Lambda will retrieve from your event source at the time of invocation. "
    default             = 100 
}

variable maximum_batching_window_in_seconds {
    description         = "The maximum amount of time to gather records before invoking the function, in seconds."
    default             = 0
}

variable  starting_position {
    description         = "The position in the stream where AWS Lambda should start reading. Must be one of AT_TIMESTAMP (Kinesis only), LATEST or TRIM_HORIZON if getting events from Kinesis or DynamoDB."
    default             = "LATEST"
}

variable parallelization_factor {
    description         = "The number of batches to process from each shard concurrently. Only available for stream sources (DynamoDB and Kinesis)."
    default             = 1
}

variable maximum_retry_attempts {
    description         = "The maximum number of times to retry when the function returns an error. "
    default             = 2
}

#variable maximum_record_age_in_seconds {
#    description         = "The maximum age of a record that Lambda sends to a function for processing"
#    default             = 604800
#}

variable bisect_batch_on_function_error {
    description         = "If the function returns an error, split the batch in two and retry. Only available for stream sources (DynamoDB and Kinesis). Defaults to false."
    default             = false
}

variable lambda_on_failure_sqs_name {
    description         = " Name of the The destination configuration SQS for failed invocations of Lambda"
}