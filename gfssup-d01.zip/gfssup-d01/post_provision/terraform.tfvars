#################################################################################################################################
# Terraform.tf for GFS SUP  (Manual Steps or Post provisioning of end-to-end Architecture)
# Refer to variables.tf for description and default value of each attribute
#################################################################################################################################


# Provider
aws_region		                = "us-east-1"

# Prefix variables
application_prefix              = "gfssup"
environment                     = "d01"

# Step 2 of readme.md
# Consumer ARN - should be obtained from  aws kinesis register-stream-consumer command output
kinesis_stream_consumer_arn     = "arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01/consumer/gfssup-kinesis-stream-consumer-01-d01:1592781833"


# Required for dlq-sqs-processor lambda
lambda_function_name_sqs        = "gfssup-dlq-sqs-processor-d01"
batch_size                      = 1

# These below will be uncommented when required
# maximum_batching_window_in_seconds  = 0
# starting_position               = "TRIM_HORIZON"
# parallelization_factor          = 2
# maximum_retry_attempts          = 2


# SQS ARN for failed attempts of Lambda processing of Kinesis Stream
lambda_on_failure_sqs_name      = "gfssup-kinesis-stream-lambda-dlq-d01"

