

data "aws_iam_policy_document" "lambda_KinesisConsumerReadOnlyAccess_policy" {

  statement {
    effect = "Allow"

    actions = [
          "kinesis:SubscribeToShard",
          "kinesis:Get*",
          "kinesis:Describe*",
          "kinesis:List*",
    ]

    resources = [
      var.kinesis_stream_consumer_arn, 
    ]
  }
}

resource "aws_iam_role_policy" "lambda_KinesisConsumerReadOnlyAccess_policy" {

  name              = "${var.application_prefix}-lambda-KinesisConsumerReadOnlyAccess-policy-${var.environment}"
  role              = "delegate-admin-${var.application_prefix}-lambda-kinesis-stream-role-${var.environment}"
  policy            = data.aws_iam_policy_document.lambda_KinesisConsumerReadOnlyAccess_policy.json
}


