# Manual steps after creating the end-to-end gfssup infrastructure (B/c Terraform doesn't support kinesis fanout consumer)
# 1. Create Kinesis Streams Consumer Fan-out using AWS CLI kinesis register-stream-consumer
# 2. Run terraform init, plan and apply in the current directory to create other pending resources dependent on fan-out consumer
# 2 (b) - Step 2 will also create trigger for 2nd lambda for dlq-sqs-processor lambda (Have to adjust the parameter valus per environment)
# 3. Create Lambda Event trigger with AWS CLI
# 4. Need to de-register before destorying end-to-end architecture infra
# 5. Need to delete the event mapping trigger before destroying the entire stack

# These commands are for reference only. Substitute the stram ARN and consumer name appropriately
===================================================================================================================
# Step 1. To register a consumer for Kinesis Streams (Create)
 aws kinesis register-stream-consumer \
     --stream-arn arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01 \
     --consumer-name gfssup-kinesis-stream-consumer-01-d01

# Results Output
{
    "Consumer": {
        "ConsumerName": "gfssup-kinesis-stream-consumer-01-d01",
        "ConsumerARN": "arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01/consumer/gfssup-kinesis-stream-consumer-01-d01:1592781833",
        "ConsumerStatus": "CREATING",
        "ConsumerCreationTimestamp": "2020-06-21T19:23:53-04:00"
    }
}

===================================================================================================================
# Step 2:
# Once the complete infra is created, create below policy for role delegate-admin-gfssup-lambda-kinesis-stream-role-d01
# Policy : gfssup-lambda-KinesisConsumerReadOnlyAccess-policy-d01
# Make sure you copy paste the consumer ARN in the terraform.tfvars from step 1
# Step 2 will also create trigger for 2nd lambda for dlq-sqs-processor lambda - Adjust values per envs for 2nd lambda
# Validate if the new policy for that role is created in AWS Console
# Next Step : Create Lambda Event source mapping trigger 
===================================================================================================================
# Step 2 b (Alternative command using AWS CLI)
<!-- aws lambda create-event-source-mapping \
--event-source-arn "arn:aws:sqs:us-east-1:504542583234:gfssup-kinesis-stream-lambda-dlq-d01" \
--function-name "gfssup-dlq-sqs-processor-d01" \
--enabled \
--batch-size 1  -->

# Step 3:
# Create Lambda Event Source Mapping Trigger with Kinesis Consumer with AWS CLI (Change names as per envs, Consumer ARN)
aws lambda create-event-source-mapping \
--event-source-arn "arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01/consumer/gfssup-kinesis-stream-consumer-01-d01:1592781833" \
--function-name "gfssup-kinesis-stream-processor-d01" \
--enabled \
--batch-size 500 \
--maximum-batching-window-in-seconds 1 \
--parallelization-factor 5 \
--starting-position LATEST \
--destination-config OnFailure={Destination=arn:aws:sqs:us-east-1:504542583234:gfssup-kinesis-stream-lambda-dlq-d01} \
--maximum-record-age-in-seconds 604800 \
--maximum-retry-attempts 10 \
<!-- --bisect-batch-on-function-error  -->

# Successful output
{
    "UUID": "58ebe537-012f-4b02-9363-119037f2f438",
    "BatchSize": 500,
    "MaximumBatchingWindowInSeconds": 1,
    "ParallelizationFactor": 5,
    "EventSourceArn": "arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01/consumer/gfssup-kinesis-stream-consumer-01-d01:1592781833",
    "FunctionArn": "arn:aws:lambda:us-east-1:504542583234:function:gfssup-kinesis-stream-processor-d01",
    "LastModified": "2020-08-11T23:35:56.563000-04:00",
    "LastProcessingResult": "No records processed",
    "State": "Creating",
    "StateTransitionReason": "User action",
    "DestinationConfig": {
        "OnFailure": {
            "Destination": "arn:aws:sqs:us-east-1:504542583234:gfssup-kinesis-stream-lambda-dlq-d01"
        }
    },
    "MaximumRecordAgeInSeconds": 604800,
    "BisectBatchOnFunctionError": false,
    "MaximumRetryAttempts": 10
}



===================================================================================================================
# Step 4 (ONLY When destroying all components)
# To delete the event mapping trigger - we need uuid from above output when trigger was created 
aws lambda delete-event-source-mapping  --uuid "58ebe537-012f-4b02-9363-119037f2f438"
===================================================================================================================
# Step 5 (ONLY When destroying all components)
# To de-register a consumer from Kinesis stream (Delete) before destory entire components stack
aws kinesis deregister-stream-consumer \
     --stream-arn arn:aws:kinesis:us-east-1:504542583234:stream/gfssup-kinesis-stream-d01 \
     --consumer-name gfssup-kinesis-stream-consumer-01-d01
===================================================================================================================
# Other commands
aws lambda list-event-source-mappings
aws kinesis list-stream-consumers
