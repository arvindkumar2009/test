# Provides a Lambda event source mapping. This allows Lambda functions to get events from Kinesis Streams Consumer fan-out


data "aws_lambda_function" "dlq_sqs_processor" {
  function_name = var.lambda_function_name_sqs
}

data "aws_sqs_queue" "kinesis_lambda_on_failure_sqs" {
  name = var.lambda_on_failure_sqs_name
}


resource "aws_lambda_event_source_mapping" "lambda_event_mapping_dlq_sqs" {
  event_source_arn                    = data.aws_sqs_queue.kinesis_lambda_on_failure_sqs.arn
  function_name                       = data.aws_lambda_function.dlq_sqs_processor.arn

  batch_size                          = var.batch_size
  # maximum_batching_window_in_seconds  = var.maximum_batching_window_in_seconds
  # starting_position                   = var.starting_position
  # parallelization_factor              = var.parallelization_factor
  # maximum_retry_attempts              = var.maximum_retry_attempts
  # #maximum_record_age_in_seconds       = var.maximum_record_age_in_seconds
  # bisect_batch_on_function_error      = var.bisect_batch_on_function_error

  # destination_config  {
  #   on_failure  {
  #     destination_arn                 = data.aws_sqs_queue.lambda_on_failure_sqs.arn
  #   }
  # }
}