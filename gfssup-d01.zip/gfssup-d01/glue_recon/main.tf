# main.tf for API Gateway to CW Logs IAM Role

module "glue" {
    
    source			        = "../../../../../../modules/analytics/glue"
    
     name                                                    = var.application_prefix
     environment                                             = var.environment
  
    
    # AWS Glue catalog DB
    enable_glue_catalog_database                            = true
    glue_catalog_database_name                              = var.glue_catalog_database_name
    glue_catalog_database_parameters                        = null

    # AWS Glue catalog table
    enable_glue_catalog_table                               = true
    glue_catalog_table_name                                 = var.glue_catalog_table_name
    glue_catalog_table_description                          = "Those resources are managed by Terraform"
    glue_catalog_table_table_type                           = "EXTERNAL_TABLE"
    glue_catalog_table_parameters                           = {
        "EXTERNAL"                          = "TRUE"
        "has_encrypted_data"                = "false"
        "classification"                    = "csv"
    }

    glue_crawler_configuration       =jsonencode(
            {
               CrawlerOutput = {
                   Partitions = {
                       AddOrUpdateBehavior = "InheritFromTable"
                    }
                }
               Grouping      = {
                   TableGroupingPolicy = "CombineCompatibleSchemas"
                }
               Version       = 1
            }
        ) 

    storage_descriptor_location      = var.storage_descriptor_location
    storage_descriptor_input_format  = var.storage_descriptor_input_format
    storage_descriptor_output_format = var.storage_descriptor_output_format
    
    glue_catalog_table_partition_keys = [
        {
            name    = "createDate"
            type    = "string"
        },
        {
            name    = "part"
            type    = "int"
        },
        ]
       
    storage_descriptor_columns       = [
        {
            columns_name    = "recordtype"
            columns_type    = "string"
            columns_comment = "recordtype"
        },
        {
            columns_name    = "transactionid"
            columns_type    = "string"
            columns_comment = "transactionid"
        },
        {
            columns_name    = "transactionstartdatetime"
            columns_type    = "string"
            columns_comment = "transactionstartdatetime"
        },
        {
            columns_name    = "transactionenddatetime"
            columns_type    = "string"
            columns_comment = "transactionenddatetime"
        },
        {
            columns_name    = "fulfillmentid"
            columns_type    = "string"
            columns_comment = "fulfillmentid"
        },
        {
            columns_name    = "productcode"
            columns_type    = "string"
            columns_comment = "productcode"
        },
        {
            columns_name    = "productattribute1"
            columns_type    = "string"
            columns_comment = "productattribute1"
        },
        {
            columns_name    = "oraganisationid"
            columns_type    = "string"
            columns_comment = "oraganisationid"
        },
        {
            columns_name    = "price"
            columns_type    = "double"
            columns_comment = "price"
        },
        {
            columns_name    = "quantity"
            columns_type    = "int"
            columns_comment = "quantity"
        },
        {
            columns_name    = "amount"
            columns_type    = "double"
            columns_comment = "amount"
        },
        {
            columns_name    = "invoicedisplayelement"
            columns_type    = "string"
            columns_comment = "invoicedisplayelement"
        },
        {
            columns_name    = "lineofservice"
            columns_type    = "string"
            columns_comment = "lineofservice"
        },
        {
            columns_name    = "location"
            columns_type    = "string"
            columns_comment = "location"
        },
        {
            columns_name    = "deliverymethod"
            columns_type    = "string"
            columns_comment = "deliverymethod"
        },
        {
            columns_name    = "invoicefieldinfo1"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo1"
        },
        {
            columns_name    = "invoicefieldinfo2"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo2"
        },
        {
            columns_name    = "invoicefieldinfo3"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo3"
        },
        {
            columns_name    = "invoicefieldinfo4"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo4"
        },
        {
            columns_name    = "invoicefieldinfo5"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo5"
        },
        {
            columns_name    = "invoicefieldinfo6"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo6"
        },
        {
            columns_name    = "invoicefieldinfo7"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo7"
        },
        {
            columns_name    = "invoicefieldinfo8"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo8"
        },
        {
            columns_name    = "invoicefieldinfo9"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo9"
        },
        {
            columns_name    = "invoicefieldinfo10"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo10"
        },
        {
            columns_name    = "invoicefieldinfo11"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo11"
        },
        {
            columns_name    = "invoicefieldinfo12"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo12"
        },
        {
            columns_name    = "invoicefieldinfo13"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo13"
        },
        {
            columns_name    = "invoicefieldinfo14"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo14"
        },
        {
            columns_name    = "invoicefieldinfo15"
            columns_type    = "string"
            columns_comment = "invoicefieldinfo15"
        },
        {
            columns_name    = "fulfillmentsystemname"
            columns_type    = "string"
            columns_comment = "fulfillmentsystemname"
        },
        {
            columns_name    = "masterreferenceid"
            columns_type    = "string"
            columns_comment = "masterreferenceid"
        },
        {
            columns_name    = "subjectname"
            columns_type    = "string"
            columns_comment = "subjectname"
        },
        {
            columns_name    = "subjectaddress"
            columns_type    = "string"
            columns_comment = "subjectaddress"
        },
        {
            columns_name    = "subjectcity"
            columns_type    = "string"
            columns_comment = "subjectcity"
        },
        {
            columns_name    = "subjectstateprov"
            columns_type    = "string"
            columns_comment = "subjectstateprov"
        },
        {
            columns_name    = "subjectzip"
            columns_type    = "string"
            columns_comment = "subjectzip"
        },
        {
            columns_name    = "producttypeidentifier"
            columns_type    = "string"
            columns_comment = "producttypeidentifier"
        },
        {
            columns_name    = "nobillindicator"
            columns_type    = "string"
            columns_comment = "nobillindicator"
        },
        {
            columns_name    = "servicecodeoverrideindicator"
            columns_type    = "string"
            columns_comment = "servicecodeoverrideindicator"
        },
        {
            columns_name    = "personaindicator"
            columns_type    = "string"
            columns_comment = "personaindicator"
        },
        {
            columns_name    = "efxid"
            columns_type    = "string"
            columns_comment = "efxid"
        },
        {
            columns_name    = "suspenseproducttype"
            columns_type    = "string"
            columns_comment = "suspenseproducttype"
        },
        {
            columns_name    = "internalreferenceid"
            columns_type    = "string"
            columns_comment = "internalreferenceid"
        },
        {
            columns_name    = "ssn"
            columns_type    = "string"
            columns_comment = "ssn"
        },
        {
            columns_name    = "productcoderateable"
            columns_type    = "string"
            columns_comment = "productcoderateable"
        },
        {
            columns_name    = "productcoderevallocationeligible"
            columns_type    = "string"
            columns_comment = "productcoderevallocationeligible"
        },
        {
            columns_name    = "productcoderevshareeligible"
            columns_type    = "string"
            columns_comment = "productcoderevshareeligible"
        },

    ]


    storage_descriptor_ser_de_info  = [
       {
            ser_de_info_name                  = "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
            ser_de_info_serialization_library = "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
            ser_de_info_parameters            = map("field.delim", "|" , "serialization.format", "|")
        }
    ]
    storage_descriptor_sort_columns = []
    storage_descriptor_skewed_info  = [
        {
            ser_de_info_name                  = "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
            ser_de_info_serialization_library = "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
            ser_de_info_parameters            = map("field.delim", "|" , "serialization.format", "|" , "mapkey.delim", "")
        }

    ]

     # Glue Crawler 
    
    enable_glue_crawler                                     = true
    glue_crawler_name                                       = var.glue_crawler_name
    glue_crawler_role                                       = var.glue_crawler_role
    glue_crawler_schedule                                   = var.glue_crawler_schedule
    
    

glue_crawler_catalog_target = (
        {
            database_name    = var.glue_catalog_database_name , tables    = [var.glue_catalog_table_name]
                  }
           
)

glue_crawler_schema_change_policy     = [
    {
        delete_behavior  =  "LOG" , update_behavior  =  "LOG"
        }
]
       
   # Tags (ALL Lowercase!)
        # Specific to EC2 Resource
        name_tag                = var.name_tag
	    costcenter_tag          = var.costcenter_tag
        projectname_tag         = var.projectname_tag
        application_group_tag   = var.application_group_tag
        application_tag         = var.application_tag
        component_type_tag      = var.component_type_tag
	    iac_tag			= var.iac_tag
        tier_tag                = var.tier_tag
        environment_tag         = var.environment_tag
        sdlc_env_tag            = var.sdlc_env_tag

}

  