
aws_region		                = "us-east-1"

# Prefix variables
application_prefix              = "gfssup"
environment                     = "d01"

#glue database
glue_catalog_database_name                              = "gfssupd01"

#glue table
glue_catalog_table_name                                 = "reconciliation_d01"

storage_descriptor_location      = "s3://efx-gfssup-d01/reconciliation"
storage_descriptor_input_format  = "org.apache.hadoop.mapred.TextInputFormat"
storage_descriptor_output_format = "org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat"

#glue crawler

glue_crawler_name                                       = ""
glue_crawler_role                                       = "arn:aws:iam::504542583234:role/delegate-admin-gfssup_glue_crawler_recon-role"
glue_crawler_schedule                                   = "cron(30 0/1 * * ? *)"

# Tags (ALL Lowercase!)
# Specific to Resource
name_tag		                = "glue crawler"
# Put costcenter in a map and list variable (child common module)
costcenter_tag		            = "12/3400"
projectname_tag		            = "gfssup"
application_group_tag	        = "gfssup"
application_tag		            = "gfssup"
component_type_tag	            = "gfssupapp"
iac_tag			                = "eds_aws_iaac"
tier_tag		                = "app"
environment_tag		            = "t01"
sdlc_env_tag		            = "test"
######################################################################################################################