variable "aws_region" {
	description	= "AWS Region where this resource will be created"
}

variable application_prefix {
    description     = "Prefix for roles and any other resource names which are dynamically changes per environment"
}

variable environment {
    description     = "A 3 letter word to represent environment used as suffix for resource names. eg., poc, d01m t01,p01 etc."
}

variable glue_catalog_database_name {
    description     = "glue_catalog_database_name"
}

variable glue_catalog_table_name {
    description     = "glue_catalog_table_name"
}

variable storage_descriptor_location {
    description     = "storage_descriptor_location"
}

variable storage_descriptor_input_format {
    description     = "storage_descriptor_input_format"
}
variable storage_descriptor_output_format {
    description     = "storage_descriptor_output_format"
}

variable glue_crawler_name {
    description     = "glue_crawler_name"
}
variable glue_crawler_role {
    description     = "glue_crawler_role"
}

variable glue_crawler_schedule {
    description     = "glue_crawler_schedule"
}

######################################################################################################################################
#                                                            TAGS
######################################################################################################################################

############# Specific to Resource Tags ###############

variable "name_tag" {
	description	= "Name of the resource"
}

variable "costcenter_tag" {
	description	= "Cost Center of Business Unit or Tribe"
}

variable "projectname_tag" {
	description	= "Project Name of the resource. e.g., <Application_Group>-<Application>-<Purpose>"
}

variable "application_group_tag" {
	description	= "Name of the application Group. e.g., MDM, C2O, EDH , EDS etc."
}

variable "application_tag" {
	description	= "Name of the application"
}

variable "component_type_tag" {
	description	= "Database or Application Component for an Application. e.g., For AIA DB - aiadb, For AIA Application - aiaapp"
}

variable "tier_tag" {
	description	= "Database or Application or Web Tier of the resource"
}

variable "iac_tag" {
	description	= "Infrastructure Code directory structure in Bitbucket"
}

variable "environment_tag" {
	description	= "Stack # of the environment where the resource is created, e.g., d03 in pedslabd03d01" 
}

variable "sdlc_env_tag" {
	description	= "SDLC Environment Name - Dev/Test/UAT/Stage/Prod"
}

########################################################### Common Tags #######################################################################

variable "maintainer_tag" {
	description	= "Name of the team who maintains the resources - IaaS team"
	default		= "eds-aws-iaas"
}
variable "businessunit_tag" {
	description	= "Business Unit which owns the infrastructure"
	default		= "eds"
}

variable "provisionedby_tag" {
	description	= "Provisioned by Terraform/Manual(From Console)"
	default		= "terraform"
}
variable "support_group_tag" {
	description	= "SNow Group for the IaaS support"
	default		= "eds_ps_awsiaas_global"
}
variable "support_email_tag" {
	description	= "IaaS Support Group Email"
	default		= "edsawsiaas@equifax.com"
}

variable "segment_tag" {
	description	= "Business Segment Name which owns the infrastructure"
	default		= "eds"
}

####################################################################### END Tags ############################################################