terraform {
  backend "s3" {
    encrypt        = true
    bucket         = "efx-cloud-gfs-nonprod-core-backend"
    dynamodb_table = "LockingTable"
    region         = "us-east-1"
    key            = "eds/aws/nonprod-acc/us-east-1/dev-vpc/dev-env/gfssup/glue_catalog/terraform-glue-recon.tfstate"
  }
}

