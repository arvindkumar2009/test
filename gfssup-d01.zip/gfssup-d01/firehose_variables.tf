# firehose_variables.tf

variable stream_as_source_to_firehose {
    description     = "Whether Kinesis Data Stream is the source for Kinesis Firehose"
    type            = bool
}

variable server_side_encryption {
    description     = "Server-side encryption should not be enabled when a kinesis stream is configured as the source of the firehose delivery stream"
    type            = bool
}

variable s3_bucket_prefix {
    description     = "Prefix to S3 bucket files <prefix><YYYY/MM/DD/HH time format >. Note that if the prefix ends with a slash, it appears as a folder in the S3 bucket"
    default         = ""
}

variable buffer_size_mb {
    description     = "Buffer incoming data to the specified size, in MBs, before delivering it to the destination"
    default         = 5
}

variable buffer_interval {
    description     = "Buffer incoming data for the specified period of time, in seconds, before delivering it to the destination. The default value is 300."
    default         = 300
}

variable compression_format {
    description     = "The compression format. If no value is specified, the default is UNCOMPRESSED.Other supported values are GZIP, ZIP & Snappy"
    default         = "UNCOMPRESSED"
}

variable kms_key_arn {
    description     = "Specifies the KMS key ARN the stream will use to encrypt data. If not set, no encryption will be used."
    default         =""
}

variable error_output_prefix {
    description     = "Prefix added to failed records before writing them to S3. This prefix appears immediately following the bucket name."
    default         = ""
}

variable s3_backup_mode {
    description     = "The Amazon S3 backup mode. Valid values are Disabled and Enabled. Default value is Disabled."
    default         = "Disabled"
}

variable s3_backup_prefix {
    description     = "Prefix for Backup of Firehose stream in S3"
    default         = ""
}

variable enable_data_processing {
    description     = "Whether to enable data processing of Kinesis Firehorse stream data using Lambda function. True/False"
    default         = false
}

variable log_rentention_in_days {
    description     = "Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, and 3653."
    default         = 3653
}

#variable "kms_key_name" {
#   description	= "Key name for the ARN for the KMS encryption key. When specifying kms_key_id, encrypted needs to be set to true."
#}


variable s3_bucket_name {
    description     = "Name of the S3 Bucket"
}

#variable s3_bucket_arn_id {
#    description = "S3 Bucket ARN ID"
#}