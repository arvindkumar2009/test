data "template_file" "model" {
  template = "${file("api_gateway_model.json")}"
}

# Rest API & Components
module "api_gateway_rest_api" {

    source                          = "../../../../../../modules/network/api_gateway/rest_api"
    
    application_prefix              = var.application_prefix
    environment                     = var.environment
    iam_boundary_policy             = var.iam_boundary_policy

    # REST API 
    rest_api_description            = var.rest_api_description
    api_endpoint_type               = var.api_endpoint_type

    # REST API CW Logs
    log_group_path                  = var.log_group_path
    log_group_name                  = var.log_group_name
    log_stream_name                 = var.log_stream_name
    log_rentention_in_days          = var.log_rentention_in_days_api

    # REST API Destination - Kinesis Stream
    stream_as_destination           = "true"
    kinesis_stream_arn_id           = module.kinesis_data_stream.kinesis_stream_arn

    # API Gateway Model
    api_gateway_model_name          = var.api_gateway_model_name
    api_gateway_model_desc          = var.api_gateway_model_desc
    model_content_type              = var.model_content_type
    api_gateway_model_schema        = data.template_file.model.rendered     # jsondecode(file("${path.module}/api_gateway_model.json"))


    # Tags (ALL Lowercase!)
        # Specific to EC2 Resource
        name_tag                = var.name_tag
        costcenter_tag          = var.costcenter_tag
        projectname_tag         = var.projectname_tag
        application_group_tag   = var.application_group_tag
        application_tag         = var.application_tag
        component_type_tag      = var.component_type_tag
	    iac_tag			        = var.iac_tag
        tier_tag                = var.tier_tag
        environment_tag         = var.environment_tag
        sdlc_env_tag            = var.sdlc_env_tag
}

# Resources
module "api_resource_streams" {

    source                          = "../../../../../../modules/network/api_gateway/rest_api/api_resource"

    rest_api_id                     = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_parent_id     = module.api_gateway_rest_api.rest_api_root_resource_id
    rest_api_resource_path          = "streams"

}

module "api_resource_stream_name" {

    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_resource"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_parent_id = module.api_resource_streams.rest_api_resource_id
    rest_api_resource_path      = "{stream-name}"

}

module "api_resource_records" {

    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_resource"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_parent_id = module.api_resource_stream_name.rest_api_resource_id
    rest_api_resource_path      = "records"

}

module "api_resource_sharditerator" {

    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_resource"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_parent_id = module.api_resource_stream_name.rest_api_resource_id
    rest_api_resource_path      = "sharditerator"

}

# Resource Methods, Integration, Method Resonse and Integration Response
module "api_gateway_method_stream_name_get" {
    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_method"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_id        = module.api_resource_stream_name.rest_api_resource_id
    http_method                 = "GET"
    authorization_type          = "NONE"
    method_request_parameters   = {"method.request.header.Content-Type" = false}

    integration_type            = "AWS"
    integration_http_method     = "POST"
    integration_uri             = "arn:aws:apigateway:us-east-1:kinesis:action/DescribeStream"
    credentials                 = module.api_gateway_rest_api.rest_api_role_arn
    integration_request_parameters  = {"integration.request.header.Content-Type" = "method.request.header.Content-Type"}
    request_templates           = {
                                    "application/json" =<<EOF
{
    "StreamName" : "$input.params('stream-name')"
}
EOF
                                }
    passthrough_behavior        = "WHEN_NO_TEMPLATES"
    # Method Response
    method_response_status_code = 200
    response_models             = { "application/json" = "Empty" }

    # Deployment
    create_stage                = "false"
    stage_name                  = var.environment                          
    cert_enabled                = "false"

    cwlogs_metrics_enabled  = var.cwlogs_metrics_enabled
    cwlogs_logging_level    = var.cwlogs_logging_level
    data_trace_enabled      = var.data_trace_enabled

}

module "api_gateway_method_records_get" {
    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_method"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_id        = module.api_resource_records.rest_api_resource_id
    http_method                 = "GET"
    authorization_type          = "NONE"
    method_request_parameters   = {"method.request.header.Shard-Iterator" = false}
    integration_type            = "AWS"
    integration_http_method     = "POST"
    integration_uri             = "arn:aws:apigateway:us-east-1:kinesis:action/GetRecords"
    credentials                 = module.api_gateway_rest_api.rest_api_role_arn
    integration_request_parameters  = {"integration.request.header.Shard-Iterator" = "method.request.header.Shard-Iterator"}
    request_templates           = {
                                    "application/json" =<<EOF
{
    "ShardIterator" = "$input.params('Shard-Iterator')"
}
EOF
                                }
    passthrough_behavior        = "WHEN_NO_TEMPLATES"
    # Responses
    method_response_status_code = 200
    response_models             = { "application/json" = "Empty" }

    # Deployment
    cert_enabled                = "false"
    stage_name                  = var.environment

    cwlogs_metrics_enabled  = var.cwlogs_metrics_enabled
    cwlogs_logging_level    = var.cwlogs_logging_level
    data_trace_enabled      = var.data_trace_enabled
}


module "api_gateway_method_sharditerator_get" {
    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_method"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_id        = module.api_resource_sharditerator.rest_api_resource_id
    http_method                 = "GET"
    authorization_type          = "NONE"
    method_request_parameters   = {"method.request.querystring.shard-id" = false}
    integration_type            = "AWS"
    integration_http_method     = "POST"
    integration_uri             = "arn:aws:apigateway:us-east-1:kinesis:action/GetShardIterator"
    credentials                 = module.api_gateway_rest_api.rest_api_role_arn
    integration_request_parameters  = {"integration.request.querystring.shard-id" = "method.request.querystring.shard-id"}
    request_templates           = {
                                    "application/json" =<<EOF
{
    "ShardId": "$input.params('shard-id')",
    "ShardIteratorType": "TRIM_HORIZON",
    "StreamName": "$input.params('stream-name')"
}
EOF
                                }
    passthrough_behavior        = "WHEN_NO_TEMPLATES"
    # Responses
    method_response_status_code = 200
    response_models             = { "application/json" = "Empty" }
    
    # Deployment
    cert_enabled                = "false"
    stage_name                  = var.environment

    cwlogs_metrics_enabled  = var.cwlogs_metrics_enabled
    cwlogs_logging_level    = var.cwlogs_logging_level
    data_trace_enabled      = var.data_trace_enabled
}


module "api_gateway_method_records_put" {
    source                      = "../../../../../../modules/network/api_gateway/rest_api/api_method"

    rest_api_id                 = module.api_gateway_rest_api.rest_api_id
    rest_api_resource_id        = module.api_resource_records.rest_api_resource_id
    http_method                 = "PUT"
    authorization_type          = "NONE"
    method_request_parameters   = {"method.request.header.Content-Type" = false}
    method_request_models       = { "application/json" = "${var.api_gateway_model_name}" }
    validate_request_body       = "true"
    validate_request_parameters = "false"

    integration_type            = "AWS"
    integration_http_method     = "POST"
    integration_uri             = "arn:aws:apigateway:us-east-1:kinesis:action/PutRecords"
    credentials                 = module.api_gateway_rest_api.rest_api_role_arn
    integration_request_parameters  = {"integration.request.header.Content-Type" = "method.request.header.Content-Type"}
    request_templates           = {
                                    "application/json" =<<EOF
{
    "StreamName": "$input.params('stream-name')",
    "Records": [
    #foreach($elem in $input.path('$.records'))
        {
            "RecordId": "$elem.recordId",
            "Data": "$elem.data",
            "PartitionKey": "$elem.kinesisRecordMetadata.partitionKey"
        }#if($foreach.hasNext),#end
        #end
    ]
}
EOF
                                }
    passthrough_behavior        = "WHEN_NO_TEMPLATES"
    # Responses
    method_response_status_code = 200
    response_models             = { "application/json" = "Empty" }

    # Deployment
    cert_enabled                = "false"
    stage_name                  = var.environment

    cwlogs_metrics_enabled  = var.cwlogs_metrics_enabled
    cwlogs_logging_level    = var.cwlogs_logging_level
    data_trace_enabled      = var.data_trace_enabled
}