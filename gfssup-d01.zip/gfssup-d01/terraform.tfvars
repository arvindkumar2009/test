#################################################################################################################################
# Terraform.tf for GFS SUP 
# Refer to variables.tf for description and default value of each attribute
#################################################################################################################################

# Provider
aws_region		                = "us-east-1"

# Prefix variables
application_prefix              = "gfssup"
environment                     = "d01"
iam_boundary_policy             = "efx-cloud-developerpoweruser-boundary-policy"

# Kinesis Data stream 
shard_count                     = 5
stream_retention_period_in_hrs  = 24
stream_encryption_type          = "KMS"
# kms_master_key_id is used for Streams encryption - see variable at the end of this file

# REST API Gateway
rest_api_description            = "REST API Gateway for GFS SUP Project"
api_endpoint_type               = "REGIONAL"

# REST API Cloud Watch Logs
log_group_path                  = "/aws/apigateway"
log_group_name                  = "gfssup-restapi-gateway-kinesis-streams-d01"
log_stream_name                 = "KinesisStreamDelivery"
log_rentention_in_days_api      = "30"

# API Gateway Model
api_gateway_model_name          = "KinesisRecords"   # Only Alphanumeric 
api_gateway_model_desc          = "Kinesis Records Json Schema"
model_content_type              = "application/json"


# Stage Settings
cwlogs_metrics_enabled          = "true"   # Enable Detailed CloudWatch Metrics
cwlogs_logging_level            = "INFO"    # Enable CloudWatch Logs/Log level should be not null 
data_trace_enabled              = "true"   # Log full requests/responses data

# Kinesis Firehose
# server_side_encryption should not be enabled when a kinesis stream is configured as the source of the firehose delivery stream
stream_as_source_to_firehose    = "true"
server_side_encryption          = "false"
s3_bucket_name                  = "efx-atlas-sup"
buffer_size_mb                  = 1
buffer_interval                 = 60
compression_format              = "UNCOMPRESSED"
# kms_master_key_id is used for Streams encryption - see variable at the end of this file
# Modify to Disabled if you do not want to write source records to S3 
s3_backup_mode                  = "Disabled"
# Firehose CW Logs
log_rentention_in_days          = "30"


# Lambda Function for Kinesis Stream
stream_as_source_to_lambda      = "true"
lambda_s3_bucket_name           = "efx-atlas-sup"
lambda_s3_bucket_key            = "atlas-sup/lambda/gfssup-kinesis-stream-processor-d01.zip"
lambda_function_file_name       = "gfssup-kinesis-stream-processor-d01"
lambda_function_handler_name    = "com.efx.gfs.lambda.KinesisProcessorHandler::handleRequest"
lambda_function_source_name     = "kinesis-stream"
lambda_function_description     = "Processes records from Kinesis data stream for GFS-SUP"
# Lambda Runtime Configuration
lambda_memory_size_mb           = 512
lambda_runtime_engine           = "java11"
lambda_timeout_secs             = 180
# -1 is no limit; Max 3000 in Us-east-1 region
lambda_reserved_conc_execs      = -1

lambda_env_variables = {
    BATCH_OPS_RETRY             = 5
    # MAX_CSV_RECORDS_PER_FILE    = 100
    # S3_BUCKET_NAME              = "efx-atlas-sup"
    # S3_PREFIX                   = "tmp/"
}


# Lambda Function for Lambda SQS Processor
stream_as_source_to_lambda_sqs      = "true"
lambda_s3_bucket_name_sqs           = "efx-atlas-sup"
lambda_s3_bucket_key_sqs            = "atlas-sup/lambda/gfssup-dlq-sqs-processor-d01.zip"
lambda_function_file_name_sqs       = "gfssup-dlq-sqs-processor-d01"
lambda_function_handler_name_sqs    = "com.efx.gfs.lambda.KinesisProcessorDLQHandler::handleRequest"
lambda_function_source_name_sqs     = "dlq-sqs"
lambda_function_description_sqs     = "Processes records from DLQ SQS of Lambda Kinesis Processor for GFS-SUP"
# Lambda Runtime Configuration
lambda_memory_size_mb_sqs           = 512
lambda_runtime_engine_sqs           = "java11"
lambda_timeout_secs_sqs             = 300
# -1 is no limit; Max 3000 in Us-east-1 region
lambda_reserved_conc_execs_sqs      = -1

lambda_env_variables_sqs = {
    BATCH_OPS_RETRY             = 5
    # MAX_CSV_RECORDS_PER_FILE    = 100
    # S3_BUCKET_NAME              = "efx-atlas-sup"
    # S3_PREFIX                   = "tmp/"
}

# Lambda Function for Lambda DDB
stream_as_source_to_lambda_ddb      = "true"
lambda_s3_bucket_name_ddb           = "efx-atlas-sup"
lambda_s3_bucket_key_ddb            = "atlas-sup/lambda/gfssup-dlq-sqs-processor-d01.zip"
lambda_function_file_name_ddb       = "gfssup-dlq-sqs-processor-d01"
lambda_function_handler_name_ddb    = "com.efx.gfs.lambda.GeneralLedgerReceivedTransactionsHandler::handleRequest"
lambda_function_source_name_ddb     = "dlq-sqs"
lambda_function_description_ddb     = "Processes records from DLQ SQS of Lambda Kinesis Processor for GFS-SUP"
# Lambda Runtime Configuration
lambda_memory_size_mb_ddb           = 512
lambda_runtime_engine_ddb           = "java11"
lambda_timeout_secs_ddb             = 300
# -1 is no limit; Max 3000 in Us-east-1 region
lambda_reserved_conc_execs_ddb      = -1

lambda_env_variables_ddb = {
    BATCH_OPS_RETRY             = 5
    # MAX_CSV_RECORDS_PER_FILE    = 100
    # S3_BUCKET_NAME              = "efx-atlas-sup"
    # S3_PREFIX                   = "tmp/"
}

# Lambda Function for Lambda S3
stream_as_source_to_lambda_s3      = "true"
lambda_s3_bucket_name_s3           = "efx-atlas-sup"
lambda_s3_bucket_key_s3            = "atlas-sup/lambda/gfssup-dlq-sqs-processor-d01.zip"
lambda_function_file_name_s3       = "gfssup-dlq-sqs-processor-d01"
lambda_function_handler_name_s3    = "com.efx.gfs.lambda.GeneralLedgerSentDataTransactionsHandler::handleRequest"
lambda_function_source_name_s3     = "dlq-sqs"
lambda_function_description_s3     = "Processes records from DLQ SQS of Lambda Kinesis Processor for GFS-SUP"
# Lambda Runtime Configuration
lambda_memory_size_mb_s3           = 512
lambda_runtime_engine_s3           = "java11"
lambda_timeout_secs_s3             = 300
# -1 is no limit; Max 3000 in Us-east-1 region
lambda_reserved_conc_execs_s3      = -1

lambda_env_variables_s3 = {
    BATCH_OPS_RETRY             = 5
    # MAX_CSV_RECORDS_PER_FILE    = 100
    # S3_BUCKET_NAME              = "efx-atlas-sup"
    # S3_PREFIX                   = "tmp/"
}

# Lambda Function for Lambda SQS2 Processor
stream_as_source_to_lambda_sqs2      = "true"
lambda_s3_bucket_name_sqs2           = "efx-atlas-sup"
lambda_s3_bucket_key_sqs2            = "atlas-sup/lambda/gfssup-dlq-sqs-processor-d01.zip"
lambda_function_file_name_sqs2       = "gfssup-dlq-sqs-processor-d01"
lambda_function_handler_name_sqs2    = "com.efx.gfs.lambda.GeneralLedgerFailedTransactionSqsHandler::handleRequest"
lambda_function_source_name_sqs2     = "dlq-sqs"
lambda_function_description_sqs2     = "Processes records from DLQ SQS of Lambda Kinesis Processor for GFS-SUP"
# Lambda Runtime Configuration
lambda_memory_size_mb_sqs2           = 512
lambda_runtime_engine_sqs2           = "java11"
lambda_timeout_secs_sqs2             = 300
# -1 is no limit; Max 3000 in Us-east-1 region
lambda_reserved_conc_execs_sqs2      = -1

lambda_env_variables_sqs2 = {
    BATCH_OPS_RETRY             = 5
    # MAX_CSV_RECORDS_PER_FILE    = 100
    # S3_BUCKET_NAME              = "efx-atlas-sup"
    # S3_PREFIX                   = "tmp/"
}

# Dynamo DB Table Source - Kinesis Streams
dynamo_db_table_stream          = {
    dynamo_table_name           = "StreamTransactions"
    hash_key                    = "id"
    range_key                   = "sortRangeId"
    stream_enabled              = "true"
    stream_view_type            = "NEW_IMAGE"
    read_capacity               = 100
    write_capacity              = 250

    attributes                  = [
        {
            name = "id"
            type = "S"
        },
        {
            name = "sortRangeId"
            type = "S"
        },
        {
            name = "rowStatus"
            type = "S"
        }
    ]

    global_secondary_indexes    = [
        {
            name               = "rowStatusIndex"
            hash_key           = "rowStatus"
            range_key          = "sortRangeId"
            projection_type    = "ALL"
            read_capacity      = 100
            write_capacity     = 500
        }
    ]

    # Autoscaling
    autoscaling_read = {
        scale_in_cooldown  = 60
        scale_out_cooldown = 60
        target_value       = 70
        max_capacity       = 250
    }

    autoscaling_write = {
        scale_in_cooldown  = 60
        scale_out_cooldown = 60
        target_value       = 70
        max_capacity       = 500
    }

    autoscaling_indexes = {
        # This variable name should match with the name of the GSI of the table
        rowStatusIndex = {
            read_max_capacity  = 250
            read_min_capacity  = 100 # Should be same as read_capacity value for the global_secondary_indexes above
            write_max_capacity = 1000
            write_min_capacity = 500 # Should be same as write_capacity value for the global_secondary_indexes above
        }
    }

    # Backup
    point_in_time_recovery_enabled = "true"

    server_side_encryption_enabled  = "true"
    # KMS Key is taken from SQS kms_master_key_id variable

}

# Dynamo DB Table Source - Batch Processing by GSS Micro Services
dynamo_db_table_batch           = {
    dynamo_table_name           = "BatchTransactions"
    hash_key                    = "id"
    range_key                   = "sortRangeId"
    stream_enabled              = "true"
    stream_view_type            = "NEW_IMAGE"
    write_capacity              = 100
    read_capacity               = 100

    attributes                  = [
        {
            name = "id"
            type = "S"
        },
        {
            name = "sortRangeId"
            type = "S"
        },
        {
            name = "rowStatus"
            type = "S"
        }
    ]

    global_secondary_indexes    = [
        {
            name               = "rowStatusIndex"
            hash_key           = "rowStatus"
            range_key          = "sortRangeId"
            projection_type    = "ALL"
            read_capacity      = 250
            write_capacity     = 250
        }
    ]

    # Autoscaling
    autoscaling_read = {
        scale_in_cooldown  = 60
        scale_out_cooldown = 60
        target_value       = 70
        max_capacity       = 250
    }

    autoscaling_write = {
        scale_in_cooldown  = 60
        scale_out_cooldown = 60
        target_value       = 70
        max_capacity       = 250
    }

    autoscaling_indexes = {
        # This variable name should match with the name of the GSI of the table
        rowStatusIndex = {
            read_max_capacity  = 500
            read_min_capacity  = 250 # Should be same as read_capacity value for the global_secondary_indexes above
            write_max_capacity = 500
            write_min_capacity = 250 # Should be same as write_capacity value for the global_secondary_indexes above
        }
    }
    
    # Backup
    point_in_time_recovery_enabled = "true"

    server_side_encryption_enabled  = "true"
    # KMS Key is taken from SQS kms_master_key_id variable
}

# Dynamo DB Table Source - Meta Data to store track processing
dynamo_db_table_meta            = {
    dynamo_table_name           = "MetaDataTransactions"
    hash_key                    = "id"
    range_key                   = "executionDate"
    stream_enabled              = "true"
    stream_view_type            = "NEW_IMAGE"
    write_capacity              = 10
    read_capacity               = 25

    attributes                  = [
        {
            name = "id"
            type = "S"
        },
        {
            name = "executionDate"
            type = "S"
        },
    ]

    # Backup
    point_in_time_recovery_enabled = "true"

    server_side_encryption_enabled  = "true"
    # KMS Key is taken from SQS kms_master_key_id variable
}

# SQS - Lambda failed transactions DLQ
enable_queue                        = "true"
enable_dlq                          = "false"
queue_name                          = "kinesis-stream-lambda-dlq"
visibility_timeout_seconds          = 300 # prev value 30
message_retention_seconds           = 345600 
max_message_size                    = 262144 
delay_seconds                       = 0
receive_wait_time_seconds           = 0
policy                              = <<POLICY
{
"Version": "2012-10-17",
"Statement": {
    "Effect": "Allow",
    "Action": "*",
    "Resource": "*"
}
}
POLICY

redrive_policy                      = ""
max_receive_count                   = 3
fifo_queue                          = "false"
content_based_deduplication         = "false"

# e.g.gfssup-kms-nonprod and gfssup-kms-prod
server_side_encryption_enabled      = "true"
kms_master_key_id                   = "alias/gfssup-kms-nonprod"
kms_data_key_reuse_period_seconds   = 300 

# SNS topic

create_sns_topic                    = "true"
sns_topic_name                      = "gfssup-alerts-d01"
sns_topic_display_name              = "gfssup_alerts for EC2 and Lambda"
policy1                             = <<POLICY1
{
  "Version": "2008-10-17",
  "Id": "__default_policy_ID",
  "Statement": [
    {
      "Sid": "__default_statement_ID",
      "Effect": "Allow",
      "Principal": {
        "AWS": "*"
      },
      "Action": [
        "SNS:Publish",
        "SNS:RemovePermission",
        "SNS:SetTopicAttributes",
        "SNS:DeleteTopic",
        "SNS:ListSubscriptionsByTopic",
        "SNS:GetTopicAttributes",
        "SNS:Receive",
        "SNS:AddPermission",
        "SNS:Subscribe"
      ],
      "Resource": "arn:aws:sns:us-east-1:504542583234:gfssup_alerts",
      "Condition": {
        "StringEquals": {
          "AWS:SourceOwner": "504542583234"
        }
      }
    }
  ]
}
POLICY1

delivery_policy                      =<<EOF
{
  "http": {
    "defaultHealthyRetryPolicy": {
      "numRetries": 3,
      "numNoDelayRetries": 0,
      "minDelayTarget": 20,
      "maxDelayTarget": 20,
      "numMinDelayRetries": 0,
      "numMaxDelayRetries": 0,
      "backoffFunction": "linear"
    },
    "disableSubscriptionOverrides": false
  }
}
EOF
  
# e.g.gfssup-kms-nonprod and gfssup-kms-prod
#kms_master_key_id                   = "alias/gfssup-kms-nonprod"

#glue_crawler

enable_glue_crawler                                     = true
glue_crawler_name                                       = ""
glue_crawler_role                                       = ["arn:aws:kms:us-east-1:504542583234:key/712bcd96-52fc-4557-b2e1-7cc734d13424"]

#glue_crawler_catalog_target                            = map("database_name", "")
#glue_crawler_schema_change_policy                      = map("delete_behavior", "LOG", "update_behavior", "LOG")

enable_glue_security_configuration                      = true
glue_security_configuration_name                        = ""


# Secrets Values
# key1_secret_value and key2_secret_value are passed via TF_VAR_key1_secret_value and TF_VAR_key2_secret_value parameters on command line using export command
# export TF_VAR_key1_secret_value=CAYQAhoFMS4wLjA=
# export TF_VAR_key2_secret_value=CAIQAhoFMS4wLjAi5QEKJgokOGQxOTQwZDYtZGNhMC00Yjk2LTliOTQtZmMzNGYwODgwZDllErgBAQIDAHgruS2jDOIBJwsLCPFZhwynslGgaNJzCCbYZqEhX8waeAG9Ci5OtRmrJV8yhhHtOYN8AAAAfjB8BgkqhkiG9w0BBwagbzBtAgEAMGgGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQM4DhlVMU/1KIXKCGEAgEQgDvt+PYLJqaaKzprYSuU1PuLuD8ZoLLua3YN5tYyoB3HZwsyXy3nQKndT1noEw0RqswyN+c2mSz4TJT0rSAB

# Tags (ALL Lowercase!)
# Specific to Resource
name_tag		        = "gfssup-d01"
# Put costcenter in a map and list variable (child common module)
costcenter_tag		    = "20/7169"
projectname_tag		    = "gfs-sup"
application_group_tag	= "mis"
application_tag		    = "gfssup"
component_type_tag	    = "gfssupapp"
iac_tag			        = "eds_aws_iaac"
tier_tag		        = "app"
environment_tag		    = "d01"
sdlc_env_tag		    = "dev"
######################################################################################################################
