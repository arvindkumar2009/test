# restapi_gw_variables.tf - For REST API Gateway

################################################### REST API ##############################################################
variable rest_api_description {
    description         = "The description of the REST API"
}

variable api_endpoint_type {
    description         = "Type of AWS API Gateway Endpoint types. Valid values: EDGE, REGIONAL or PRIVATE"
    default             = "REGIONAL"
}

#variable binary_media_types {
#	description			= "The list of binary media types supported by the RestApi. By default, the RestApi supports only UTF-8-encoded text payloads."
#	default				= ""
#}

#variable minimum_compression_size {
#	description			= "Minimum response size to compress for the REST API.-1 disables compression (default)"
#	default				= -1
#}

#variable open_api_specs_body {
#	description			= "An OpenAPI specification that defines the set of routes and integrations to create as part of the REST API."
#	default				= ""
#}

#variable api_gateway_policy {
#	description			= "JSON formatted policy document that controls access to the API Gateway."
#	default				= ""
#}

#variable api_key_source {
#	description			= "The source of the API key for requests. Valid values are HEADER (default) and AUTHORIZER."
#	default				= "HEADER"
#}

# Cloud Watch Logs for Rest API
variable log_group_path {
    description     = "Path name of the Cloud watch Log Group"
}

variable log_group_name {
    description     = "Cloud Watch Log Group Name"
}

variable log_rentention_in_days_api {
    description     = "Specifies the number of days you want to retain log events in the specified log group. Possible values are: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, and 3653."
    default         = 3653
}

variable log_stream_name {
    description     = "Name of the CW Log Stream"
}

# Stage Settings
variable cwlogs_metrics_enabled {
    description     = "Whether to enable CW Logs for stage methods. True/False"
    type            = bool
    default         = false
}

variable cwlogs_logging_level {
    description     = "CW Logging Level; The available levels are OFF, ERROR, and INFO."
    default         = "ERROR"
}

variable data_trace_enabled {
    description     = "whether data trace logging is enabled. True/False"
    type            = bool
    default         = false
}
######################################### Model ############################################################################
variable api_gateway_model_name {
	description		= "The name of the model for API gateway"
}

variable api_gateway_model_desc {
	description		= "The description of the model."	
}

variable model_content_type {
	description		= "The content type of the model"
	default			= "application/json"
}

#############################################################################################################################


