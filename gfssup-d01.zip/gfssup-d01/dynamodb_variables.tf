# dynamodb_variables.tf - Dynamo DB Variables

########################################## Dynamo DB Table ##############################################################
variable dynamo_db_table_stream {
  description   = "Any list of Maps or key/value pairs for DynamoDB Table when source is Kinesis Streams"
  type        = any
}

variable dynamo_db_table_batch {
  description   = "Any list of Maps or key/value pairs for DynamoDB Table when source is Kinesis Streams"
  type        = any
}

variable dynamo_db_table_meta {
  description   = "Any list of Maps or key/value pairs for DynamoDB Table when source is Kinesis Streams"
  type        = any
}

variable dynamo_db_table_map {
  description   = "A map of Any list or key/value pairs for DynamoDB Table when source is Kinesis Streams"
  type        = any
  default     = {}
}

variable "billing_mode" {
  description = "Controls how you are billed for read/write throughput and how you manage capacity. The valid values are PROVISIONED or PAY_PER_REQUEST"
  type        = string
  default     = "PAY_PER_REQUEST"
  }

variable "write_capacity" {
  description = "The number of write units for this table. If the billing_mode is PROVISIONED, this field should be greater than 0"
  type        = number
  default     = 100
}

variable "read_capacity" {
  description = "The number of read units for this table. If the billing_mode is PROVISIONED, this field should be greater than 0"
  type        = number
  default     = 250
}

variable "global_secondary_indexes" {
  description = "Describe a GSI for the table; subject to the normal limits on the number of GSIs, projected attributes, etc."
  type        = list(any)
  default     = []
}

variable "server_side_encryption_enabled" {
  description = "Whether or not to enable encryption at rest using an AWS managed KMS customer master key (CMK)"
  type        = bool
  default     = false
}

variable "server_side_encryption_kms_key_arn" {
  description = "The ARN of the CMK that should be used for the AWS KMS encryption. This attribute should only be specified if the key is different from the default DynamoDB CMK, alias/aws/dynamodb."
  type        = string
  default     = ""
}

variable "point_in_time_recovery_enabled" {
  description = "Whether to enable point-in-time recovery"
  type        = bool
  default     = false
}

# ====================== variables for auto scaling ======================

variable "autoscaling_read" {
  description = "A map of read autoscaling settings. `max_capacity` is the only required key. See example in examples/autoscaling"
  type        = map(string)
  default     = {}
}

variable "autoscaling_write" {
  description = "A map of write autoscaling settings. `max_capacity` is the only required key. See example in examples/autoscaling"
  type        = map(string)
  default     = {}
}

variable "autoscaling_indexes" {
  description = "A map of index autoscaling configurations. See example in examples/autoscaling"
  type        = map(map(string))
  default     = {}
}
##########################################################################################################################