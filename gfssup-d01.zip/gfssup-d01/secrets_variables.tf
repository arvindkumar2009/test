# Secrets variables.tf
variable secret_name {
    description     = "Specifies the friendly name of the new secret. The secret name can consist of uppercase letters, lowercase letters, digits, and any of the following characters: /_+=.@-"
    default         = null
}

variable secret_description {
    description     = "A description of the secret"
    default         = null
}

variable secret_kms_key_arn {
    description     = "Optional. Specifies the ARN or alias of the AWS KMS customer master key (CMK) to be used to encrypt the secret values in the versions stored in this secret"
    default         = null
}

variable secret_value {
    description     = "Specifies text data that you want to encrypt and store in this version of the secret."
    type            = map(string)
    default         = {
        keyReference        = "Dummy"
        ddb2EncodedKey      = "Dummy"
    }
}

variable key1_secret_value {
    description = "Value for the First Key in the secrets - key1_secret_value"
}

variable key2_secret_value {
    description = "Value for the Second Key in the secrets - key2_secret_value"
}